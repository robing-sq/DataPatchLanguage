
void do_work()
{
  
}


int main(int argc,
	 char* argv[])
{
  
  do_work();

  return 0;
}
