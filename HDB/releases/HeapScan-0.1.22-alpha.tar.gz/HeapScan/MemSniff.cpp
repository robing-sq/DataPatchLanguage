/***************************************************************************
 *  HeapScan: a data-oriented debugging tool 
 *  Copyright (C) 2008-2009 Michael E. Locasto
 *
 *  All rights reserved.
 * 
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 *
 * $Id$
 **************************************************************************/

#include "MemSniff.hpp"

//UINT64 m_read_count = 0;
//UINT64 m_write_count = 0;
//UINT64 m_total_memory_operations = 0;
